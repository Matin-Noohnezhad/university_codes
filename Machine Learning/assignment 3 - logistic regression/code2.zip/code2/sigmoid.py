import numpy as np
def sigmoid(z):
	#SIGMOID Compute sigmoid functoon
	#   J = SIGMOID(z) computes the sigmoid of z.

	# You need to return the following variables correctly 
	
	g = np.zeros(1);

	# ====================== YOUR CODE HERE ======================
	# Instructions: Compute the sigmoid of each value of z (z can be a matrix,
	#               vector or scalar).

	
	# =============================================================

	return g
